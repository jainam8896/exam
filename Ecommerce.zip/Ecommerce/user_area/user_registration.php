<?php
include('../includes/connect.php');
if(isset($_POST["submit"])){
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    // $sp = md5($password);
    $confirmpassword = $_POST["confirmpassword"];
    $duplicate = mysqli_query($conn, "select * from tb_user where username = '$username' or email = '$email'");
    if(mysqli_num_rows($duplicate) > 0){
        echo "<script> alert('User Already Exist'); </script>";
    }
    else{
        if($password == $confirmpassword){
            $query = "insert into tb_user (username,email,password) values('$username','$email','$password')";
            mysqli_query($conn,$query);
            echo "<scripe> alert('Registration Successful'); </script>";
            // header("location: login.php");
        }
        else{
            echo "<scripe> alert('Password Does Not Match'); </script>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login and Sign Up form</title>
    <link rel="stylesheet" href="../s1.css">
</head>

<body>
    <div class="wrapper">
        <h1>Sign Up</h1>
        <form class="" action="reg.php" method="post">
            <input type="text" name="username" id="username" placeholder="Username" required>
            <input type="text" name="email" id="email" placeholder="Email" required>
            <!-- <input type="text" name="phonenumber" id="phonenumber" placeholder="Phonenumber"> -->
            <input type="password" name="password" id="password" placeholder="Password" required>
            <input type="password" name="confirmpassword" id="confirmpassword" placeholder="Confirm Password" required>
            <button type="submit" name="submit">Sign UP</button>
        </form>
        <div class="member">
             Already a member? <a href="../user_area/user_login.php">
                 Login Here
             </a>
        </div>
    </div>
</body>
</html>