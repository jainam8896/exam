<?php
include('../includes/connect.php');
if (isset($_POST['insert_brand'])) {
    $brand_title = $_POST['brand_title'];
    $select_query = "select * from tb_brand where brand_title='$brand_title'";
    $res_select = mysqli_query($conn, $select_query);
    $number = mysqli_num_rows($res_select);
    if ($number > 0) {
        echo "<script>alert('Brand Already Added')</script>";
    } else {
        $sql = "insert into tb_brand (brand_title) values('$brand_title')";
        $res = mysqli_query($conn, $sql);
        if ($res) {
            echo "<script>alert('Brand Added Successful')</script>";
        }
    }
}
?>

<h2 class="text-center">Insert Brands</h2>
<form action="" method="post" class="mb-2">
    <div class="input-group w-90 mb-2">
        <span class="input-group-text bg-info" id="basic-addon1"><i class="fa-solid fa-recepit"></i></span>
        <input type="text" class="form-control" name="brand_title" placeholder="Insert Brands" aria-label="Brands" aria-describedby="basic-addon1" required>
    </div>
    <div class="input-group w-10 mb-2 m-auto">
        <input type="submit" class="bg-info border-0 p-2 my-3" name="insert_brand" value="Insert Brand">

    </div>
</form>